{{- define "dask.fullname" -}}
{{- printf "%s" .Release.Name -}}
{{- end -}}